#ifndef MainH
#define MainH

// vcl
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <VirtualTrees.hpp>
#include <Vcl.Imaging.pngimage.hpp>
#include <Vcl.Graphics.hpp>
#include <Vcl.AppEvnts.hpp>
#include <Vcl.ComCtrls.hpp>
#include <Vcl.ExtCtrls.hpp>

// std
#include <memory>

class TMainForm : public TForm
{
    __published:
        TVirtualDrawTree *vdtDemo_Without;
        TVirtualDrawTree *vdtDemo_With;
        TApplicationEvents *aeEvents;
        TPanel *pa1;
        TLabel *la1;
        TTrackBar *tb1;
    TPanel *pa2;
    TLabel *la2;
    TLabel *la3;

        void __fastcall vdtDemoDrawNode(TBaseVirtualTree *Sender, const TVTPaintInfo &PaintInfo);
        void __fastcall vdtDemoMeasureItem(TBaseVirtualTree *Sender, TCanvas *TargetCanvas, PVirtualNode Node,
              int &NodeHeight);
        void __fastcall aeEventsMessage(tagMSG &Msg, bool &Handled);

    public:
        __fastcall TMainForm(TComponent* pOwner);

    private:
        std::unique_ptr<TPngImage> m_pImage;
};
extern PACKAGE TMainForm* MainForm;
#endif
