#include <vcl.h>
#pragma hdrstop
#include "Main.h"

#include <string>

#pragma package(smart_init)
#pragma link "VirtualTrees"
#pragma resource "*.dfm"

//---------------------------------------------------------------------------
TMainForm* MainForm;
//---------------------------------------------------------------------------
__fastcall TMainForm::TMainForm(TComponent* pOwner) :
    TForm(pOwner)
{
    vdtDemo_Without->ChildCount[NULL] = 1000;
    vdtDemo_With->ChildCount[NULL] = 1000;

    m_pImage.reset(new TPngImage());
    m_pImage->LoadFromFile(L"..\\..\\Images\\Demo.png");
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::vdtDemoDrawNode(TBaseVirtualTree *Sender, const TVTPaintInfo &PaintInfo)
{
    PaintInfo.Canvas->Brush->Color = PaintInfo.Node->Index % 2 ? clWhite: clSilver;
    PaintInfo.Canvas->Brush->Style = bsSolid;
    PaintInfo.Canvas->FillRect(PaintInfo.CellRect);

    PaintInfo.Canvas->Draw(10, 10, m_pImage.get());

    std::wstring text;

    if (PaintInfo.Node->Index % 2)
        text = L" For many connoisseurs and lovers of Latin literature, Virgil is the first poet due to his epic poem the \"Aeneid\". The second poet would be the lyrical Horace.\r\n\r\nFor some of these people the best poem written in Latin is precisely the Oda number 7 from the book IV by Horace. Naturally, about the likes, nothing is written; after all any artistic assessment is just a personal judgment because it is not only affected by the cold rational assessment.\r\n\r\nIn any case a particular value should have this poem for the famous philologist, scholar and english poet Alfred Edward Housman (1859 - 1936), extraordinary professor of Latin at Cambridge from 1911 to 1936, who considered this the most beautiful poem of old literature.\r\n\r\nG. Highet tells in his book �The Classical Tradition. Greek and Roman influences on Western literature�, the following anecdote, related to Housman:\r\n\r\nIn May, 1914, in the burgeoning spring, he was commenting the poem to his students at Cambridge and surprised them with a personal confession (absolutely unexpected in such a serious teacher): �This, said hastily, almost like a man who betrays a secret, is for me the most beautiful poem in ancient literature�, and he left the classroom excited. Naturally also the most serious and severe teachers have a sensitive heart.\r\n\r\nIt is the Epicurean thought what encourages this composition. In this poem the return of spring, already heralded with irresistible force, and the succession of the seasons, warn us that everything passes; but as the years are renewed cyclically, this don�t happen to men; when our sunset comes (we don�t know when) we do not return to life, we are only dust (in the urn) and shadow (in the afterlife), not even the gods can resurrect men; so that we have to seize the moment.";
    else
        text = L"The snow is fled: the trees their leaves put on,\r\nThe fields their green:\r\nEarth owns the change, and rivers lessening run\r\nTheir banks between.\r\nNaked the Nymphs and Graces in the meads\r\nThe dance essay:\r\n�No 'scaping death� proclaims the year, that speeds\r\nThis sweet spring day.\r\nFrosts yield to zephyrs; Summer drives out Spring,\r\nTo vanish, when\r\nRich Autumn sheds his fruits; round wheels the ring,�\r\nWinter again!\r\nYet the swift moons repair Heaven's detriment:\r\nWe, soon as thrust\r\nWhere good Aeneas, Tullus, Ancus went,\r\nWhat are we? dust.\r\nCan Hope assure you one more day to live\r\nFrom powers above?\r\nYou rescue from your heir whate'er you give\r\nThe self you love.\r\nWhen life is o'er, and Minos has rehearsed\r\nThe grand last doom,\r\nNot birth, nor eloquence, nor worth, shall burst\r\nTorquatus' tomb.\r\nNot Dian's self can chaste Hippolytus\r\nTo life recall,\r\nNor Theseus free his loved Pirithous\r\nFrom Lethe's thrall.";

    // background is transparent
    ::SetBkMode(PaintInfo.Canvas->Handle, TRANSPARENT);

    // select foreground color
    ::SetTextColor(PaintInfo.Canvas->Handle, clBlack);

    std::unique_ptr<TFont> pFont(new TFont);
    pFont->Size = 8;

    PaintInfo.Canvas->Font->Assign(pFont.get());
    ::SelectObject(PaintInfo.Canvas->Handle, pFont->Handle);

    ::DrawText(PaintInfo.Canvas->Handle, text.c_str(), text.length(), &PaintInfo.CellRect, DT_WORDBREAK | DT_EDITCONTROL);

    if (tb1->Position)
        ::Sleep(tb1->Position);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::vdtDemoMeasureItem(TBaseVirtualTree *Sender, TCanvas *TargetCanvas, PVirtualNode Node,
          int &NodeHeight)
{
    NodeHeight = Node->Index % 2 ? 200 : 210;
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::aeEventsMessage(tagMSG& msg, bool &Handled)
{
    if (msg.message == WM_MOUSEWHEEL)
    {
        ::SendMessage(vdtDemo_Without->Handle, WM_MOUSEWHEEL, msg.wParam, msg.lParam);
        ::SendMessage(vdtDemo_With->Handle, WM_MOUSEWHEEL, msg.wParam, msg.lParam);
        Handled = true;
    }
}
//---------------------------------------------------------------------------
